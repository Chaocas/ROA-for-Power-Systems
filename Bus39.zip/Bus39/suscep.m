function B=suscep

%%
data=case39;                                                       % Call data on IEEE 39-Bus System
n_e=length(data.branch(:,1));                                 % Number of elements
n_b= length(data.bus(:,1));                                     % Number of buses
Pbase=data.baseMVA;                                         % Power base
A=zeros(n_e,n_b);                                                % Node-element incidence matrix        

for i=1:n_e    
    
    A(i,data.branch(i,1))=-1;    
    A(i,data.branch(i,2))=1;

end

Yp=-data.branch(:,4).^-1;
B=A'*diag(Yp)*A;

end