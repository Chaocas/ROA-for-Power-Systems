function y=InROA(x, y, x_rad, y_rad)

Rx = x_rad;
Ry = y_rad;

z=x^2/(Rx)^2+y^2/(Ry)^2-1;

    if(z<=0)

        y=1;

    else

        y=0;

    end

end