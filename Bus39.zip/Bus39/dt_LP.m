function z = dt_LP(x)

global D_new;

z=-D_new*x(1,2)^2;

end