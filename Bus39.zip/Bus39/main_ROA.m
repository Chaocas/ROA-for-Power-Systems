tspan = [0 20];

x0 = [1 1];

[t,x] = ode23(@swing, tspan, x0);

figure(1)
subplot(1,2,1)
z=plot(t,x,'-o');
xlabel('Time[s]')
ylabel('States')
legend([z(1), z(2)], '\delta','\omega');
grid on

subplot(1,2,2)
plot(x(:,1),x(:,2),'-b*')
grid on
xlabel('\delta')
ylabel('\omega')
axis([-2 2 -1 1]);
hold on

% figure(2)
% 
% for i=-5:0.1:5
%     
%     y1=sqrt(3)*cos(i)-sin(i);
%     
%     y2=pi/3-i;
%     
%     plot(i,y1,'r.')
%     
%     hold on
%     
%     plot(i,y2,'b.')
%     
%     hold on
%     
% end


for i=-0.84:0.01:1.04
    
    y1=sqrt(5*(sqrt(3)*cos(i)+i-sin(i))/6-5*pi/18);
    y2=-sqrt(5*(sqrt(3)*cos(i)+i-sin(i))/6-5*pi/18);
    
    subplot(1,2,2)
    plot(i,y1,'r.')
    hold on
    
    subplot(1,2,2)
    plot(i,y2,'r.')
    hold on
    
end