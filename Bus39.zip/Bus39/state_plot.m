function state_plot(x)

plot(x(:,1),x(:,2),'b')
grid on
plot(x(1,1),x(1,2),'g+')
hold on
% xlabel('$\psi_1$','Interpreter','latex');
% ylabel('$\dot{\psi}_1$','Interpreter','latex');
% axis([-5 5 -5 5]);
hold on

end