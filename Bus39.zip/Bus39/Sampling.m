% Interpolation method to look for Vmax 

function [output, input, sig] = Sampling(c_eq, x_0)

tspan = linspace(0,50,201);

sig=0;                                                                        % 0-stable sampling point; 1-unstable sampling point
input=[];
output=[];

    [t,x] = ode23(@swing, tspan, x_0);

    if(norm(x(end,:)-c_eq)<0.5)

        input=x(1,:);
        output = LPF(t(1:end),x(1:end,:));                             % the error for Lyapunov function
                                                                                     % feasible sampling sequence
    else

        sig=1;                                                                    % unstable sampling points 

    end
        
end