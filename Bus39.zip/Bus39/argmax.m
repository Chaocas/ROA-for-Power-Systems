
function Y=argmax(mu_1,var_1,beta_sq,xs)

x=mu_1+beta_sq*sqrt(var_1);

maximum = max(x);

max_ind=find(x==maximum);

if(numel(max_ind)>1)
   
    ind=max_ind(1);
    
else
    
    ind=max_ind;
    
end

Y=xs(:,ind)';

end
