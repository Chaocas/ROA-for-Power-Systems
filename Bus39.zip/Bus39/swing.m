function y=swing(t,x)

ind=[30 32 33 34 35 36 37 38 39];   % coordinate exchange 1 

a=machin;

B=suscep;

theta=node_theta;

y=zeros(18,1);

z=zeros(39,1);

z(ind,1)=[x(1) x(3) x(5) x(7) x(9) x(11) x(13) x(15) x(17)];

    for i=1:9

        y(2*i-1,1)=x(2*i);
        
        Tem=0;
        
        for j=1:39

             Tem=Tem+B(ind(1,i),j)*(sin(theta(ind(i))-theta(j))-sin(theta(ind(i))-theta(j)+x(2*i-1)-z(j,1)));
        
        end
        
        y(2*i,1)=-a.D(i,1)*x(2*i)/a.M(i,1)+Tem/a.M(i,1);
        
    end

end