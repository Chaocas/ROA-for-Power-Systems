function [x_rad, y_rad] = ROA_plot(k)

pem=suscep;
L=-diag(pem);

tem=machin;
M=tem.M;

Bm=pem+diag(L);
zem=max(Bm(1,:));

for i=1:39
    
    for j=1:39
        
        if(Bm(i,j)<zem)&&(Bm(i,j)~=0)
          zem=Bm(i,j);      
        end
        
    end
    
end

theta=node_theta;

lamb=max(theta)-min(theta);

C=zem*(2*cos(lamb)-(pi-2*lamb)*sin(lamb));

xRadius = sqrt(C/L(k));
yRadius = sqrt(C/M(k));

theta = 0 : 0.1 : 2*pi;

x = xRadius * cos(theta);
y = yRadius * sin(theta);

x_rad = xRadius;
y_rad = yRadius;

plot(x, y, 'r.', 'LineWidth', 2);
    
end




