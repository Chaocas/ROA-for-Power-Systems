function Y=Beta_sqrt(delta1,Bg,n)

c=0.02;

beta_delta1=2*Bg+300*c*log(n)^3*log(n/delta1)^3;

beta_sqrt=sqrt(beta_delta1);

Y=beta_sqrt;

end