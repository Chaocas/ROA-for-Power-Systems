% Estimate the ROA with Confidence Level 
% Collect sampling points along the stable trajectories 
% GP-UCB Sampling Rule 
% IEEE 39 Bus System
% Created by Chao Zhai at School of EEE, NTU 
% Date: May 16, 2019 

clc;
clear all;
close all;

n_train=400;                                % number of traning data (sampling points)
 
c_eq=zeros(1,18);                           % equilibrium point of swing equation [delta  omega] for 9 machines

delta1=0.05;                                % tune the confidence level

%% GP-UCB Algorithm

sp=[];                                                                   % stable sampling points
x=[];
y=[];

wid=1.68;
x0 =wid*(rand(1,18)-0.5);                                           % The initial point is selected at random

%% Specify the mean, covariance and likelihood functions 

meanfunc = [];                                                      % Empty: don't use a mean function  meanZero
covfunc = @covSEiso;                                                % Squared Exponental covariance function @covSEiso
likfunc = @likGauss;                                                % Gaussian likelihood 
hyp = struct('mean', [], 'cov', [-1.35 -0.1], 'lik', -5);

num=1e3;                                                             % number of test points for GP-UCB rule
k=1;

while(k<=n_train)
    
[output, input, sig]=Sampling(c_eq, x0);

if(sig==1)
    
    x0 = wid*(rand(1,18)-0.5); 
    continue;
    
end

if(ismember(x0,sp)==1)
    
    x0 = wid*(rand(1,18)-0.5); 
    continue;
    
end

x=[x; input];
y=[y; output];

sp=[sp; x0];

Vmax=max(y);

xs=wid*(rand(18,num)-0.5);
hyp2 = minimize(hyp, @gp, -300, @infGaussLik, meanfunc, covfunc, likfunc, x, y);

mean=zeros(18,num);
var=zeros(18,num);

[mu_1, var_1] = gp(hyp2, @infGaussLik, meanfunc, covfunc, likfunc, x, y, xs');

max(var_1),                % uncertainty should be reduced as sampling points increase

% figure(1);
% hold on
% delete(gca);
% plot(s2,'b'),
% axis([0 1e2 0 2e2]);

xs_0=zeros(k,1);
[ymu , ~ ,~, ~] = gp(hyp2, @infGaussLik, meanfunc, covfunc, likfunc, x, y, xs_0);
% Bg=(max(ymu)+sqrt(max(ys2)))^2;
Bg=(max(ymu))^2;

beta_sq=Beta_sqrt(delta1,Bg,k);

% Choose new sampling point with the maximum value (mu+beta^{1/2}*sigma)

x0 = argmax(mu_1,var_1,beta_sq,xs);

k=k+1;

k,

end

%% Draw figures

figure(2)

x1= linspace(-wid/2,wid/2,41);   % delta
x2= linspace(-wid/2,wid/2,41);   % omega
xs = apxGrid('expand',{x1',x2'});

% keep_data=zeros(numel(x1),numel(x2),3);               % 1-delta   2-omega 3-z
% xs = apxGrid('expand',{x1',x2'});
% xs_test=zeros(numel(xs(:,1)),18);


for k=1:9

keep_data=zeros(numel(x1),numel(x2),3);               % 1-delta   2-omega 3-z
xs_test=zeros(numel(xs(:,1)),18);    
    
subplot(3,3,k);    
plot(sp(:,2*k-1), sp(:,2*k), 'g.', 'MarkerSize',5, 'LineWidth', 1); 
hold on
grid on

axis([-wid/2 wid/2 -wid/2 wid/2]);

[x_rad, y_rad] = ROA_plot(k);

xs_test(:,(2*k-1):2*k)=xs;

[ymu, ys2] = gp(hyp2, @infGaussLik, meanfunc, covfunc, likfunc, x, y, xs_test);

mat_ymu=vec2mat(ymu,numel(x1))';
mat_ys2=vec2mat(sqrt(ys2),numel(x2))';

for i=1:numel(x1)
    
    for j=1:numel(x2)
        
        keep_data(i,j,1)=x1(i);                                    % delta
        keep_data(i,j,2)=x2(j);                                    % omega
        keep_data(i,j,3)=mat_ymu(i,j)+beta_sq*(mat_ys2(i,j))-Vmax;
    
    end
    
end

% To plot the predictive mean at the test points together with the 
% 95% confidence bounds and training data 

for i=1:numel(x1)
    
    for j=1:numel(x2)
        
        if (keep_data(i,j,3)<=0)&&(InROA(keep_data(i,j,1), keep_data(i,j,2), x_rad, y_rad)==0)
            
            subplot(3,3,k);    
            plot(keep_data(i,j,1),keep_data(i,j,2),'y.');
            hold on
    
        end
        
    end
    
end

switch k
    case 1
        h_x=xlabel('$\psi_1$', 'Interpreter','latex','FontSize',12);
        get(h_x);
        h_y=ylabel('$\dot{\psi}_1$','Interpreter','latex','FontSize',12);
        get(h_y);
        axis on;
        box on;
    case 2
        h_x=xlabel('$\psi_2$', 'Interpreter','latex','FontSize',12);
        get(h_x);
        h_y=ylabel('$\dot{\psi}_2$','Interpreter','latex','FontSize',12);
        get(h_y);
        axis on;
        box on;
    case 3
        h_x=xlabel('$\psi_3$', 'Interpreter','latex','FontSize',12);
        get(h_x);
        h_y=ylabel('$\dot{\psi}_3$','Interpreter','latex','FontSize',12);
        get(h_y);
        axis on;
        box on;
    case 4
        h_x=xlabel('$\psi_4$', 'Interpreter','latex','FontSize',12);
        get(h_x);
        h_y=ylabel('$\dot{\psi}_4$','Interpreter','latex','FontSize',12);
        get(h_y);
        axis on;
        box on;
    case 5
        h_x=xlabel('$\psi_5$', 'Interpreter','latex','FontSize',12);
        get(h_x);
        h_y=ylabel('$\dot{\psi}_5$','Interpreter','latex','FontSize',12);
        get(h_y);
        axis on;
        box on;
    case 6
        h_x=xlabel('$\psi_6$', 'Interpreter','latex','FontSize',12);
        get(h_x);
        h_y=ylabel('$\dot{\psi}_6$','Interpreter','latex','FontSize',12);
        get(h_y);
        axis on;
        box on;
    case 7
        h_x=xlabel('$\psi_7$', 'Interpreter','latex','FontSize',12);
        get(h_x);
        h_y=ylabel('$\dot{\psi}_7$','Interpreter','latex','FontSize',12);
        get(h_y);
        axis on;
        box on;
    case 8
        h_x=xlabel('$\psi_8$', 'Interpreter','latex','FontSize',12);
        get(h_x);
        h_y=ylabel('$\dot{\psi}_8$','Interpreter','latex','FontSize',12);
        get(h_y);
        axis on;
        box on;   
    case 9
        h_x=xlabel('$\psi_9$', 'Interpreter','latex','FontSize',12);
        get(h_x);
        h_y=ylabel('$\dot{\psi}_9$','Interpreter','latex','FontSize',12);
        get(h_y);
        axis on;
        box on;         
end

end

load handel;
sound(y,Fs);
