function z=LPF(t,x)

sum=0;

dt=diff(t);  

% compute the value of Lyapunov function at each sampling point

for i=1:numel(dt);

    tem=x(i+1,:);
    
    sum=sum+norm(tem)^2*dt(i);

end
    
z=sum;

end





