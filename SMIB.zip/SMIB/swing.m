function y=swing(t,x)

M=12;           % 12
D=20;            % 20
K=10;            % 10
Pm=0.5;        % 0.5
c=asin(0.05);

y=[x(2); (Pm-D*x(2)-K*sin(c+x(1)))/M];

end