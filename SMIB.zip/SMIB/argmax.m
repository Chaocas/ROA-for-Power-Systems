
function Y=argmax(mu,s2,beta_sq,xs)

x=mu+beta_sq*sqrt(s2);

maximum = max(x);

max_ind=find(x==maximum);

Y=[xs(max_ind,1) xs(max_ind,2)];

end