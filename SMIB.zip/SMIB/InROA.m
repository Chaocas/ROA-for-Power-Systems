function y=InROA(x,y)

Rx = 18.45/10;
Ry = 18.45/12;

    z=x^2/Rx+y^2/Ry-1;

    if(z<=0)

        y=1;

    else

        y=0;

    end


end