% Estimate the ROA with Confidence Level 
% Collect sampling points along the stable trajectories 
% GP-UCB Sampling Rule 
% Created by Chao Zhai at School of EEE, NTU 
% Date: May 13, 2019 

clc;
clear all;
close all;

n_train=100;                              % number of traning data (sampling points)
 
c_eq=[0 0];                                % equilibrium point of swing equation [delta  omega]

delta1=0.05;                              % tune the confidence level

%% GP-UCB Algorithm

sp=[];                                       % stable sampling points
x=[];
y=[];

x1=4*(rand-0.5);
x2=4*(rand-0.5);
x0 = [x1 x2];                                     % The initial point is selected at random

[xs1 xs2]=meshgrid(-2:0.04:2,-2:0.04:2);
xs=[xs1(:) xs2(:)];

% Specify the mean, covariance and likelihood functions 

meanfunc = [];                                                      % Empty: don't use a mean function  meanZero
covfunc = @covSEiso;                                           % Squared Exponental covariance function @covSEiso
likfunc = @likGauss;                                             % Gaussian likelihood 
hyp = struct('mean', [], 'cov', [0 -1], 'lik', -10);

k=1;

while(k<=n_train)
    
[output input sig]=Sampling(c_eq, x0);

if(sig==1)
    
    x1=10*(rand-0.5);
    x2=10*(rand-0.5);
    x0 = [x1 x2];   
    continue;
    
end

if(ismember(x0,sp)==1)
    
    x1=4*(rand-0.5);
    x2=4*(rand-0.5);
    x0 = [x1 x2];   
    continue;
    
end

x=[x; input];
y=[y; output];

sp=[sp; x0];

Vmax=max(y);

% Initialize the hyperparameter struct  

% if(k==1)
%    hyp = struct('mean', [], 'cov', [0 0], 'lik', -1);
% else
%    hyp=hyp2;    
% end

hyp2 = minimize(hyp, @gp, -100, @infGaussLik, meanfunc, covfunc, likfunc, x, y);
[mu s2] = gp(hyp2, @infGaussLik, meanfunc, covfunc, likfunc, x, y, xs);
max(s2),                % uncertainty should be reduced as sampling points increase

figure(1);
hold on
delete(gca);
plot(s2,'b'),
axis([0 2e3 0 2e2]);

 xs_0=zeros(k,1);
 [ymu , ~ ,~, ~] = gp(hyp2, @infGaussLik, meanfunc, covfunc, likfunc, x, y, xs_0);
% Bg=(max(ymu)+sqrt(max(ys2)))^2;
Bg=(max(ymu))^2;

% Bg=10;

beta_sq=Beta_sqrt(delta1,Bg,k);

% Choose new sampling point with the maximum value (mu+beta^{1/2}*sigma)

x0=argmax(mu,s2,beta_sq,xs);

k=k+1;

k,

end

%% Draw figures

figure(1)
plot(sp(:,1), sp(:,2), 'g+', 'MarkerSize',5, 'LineWidth', 2); 
hold on
grid on
% h_x=xlabel('$\psi_1$','Interpreter','latex','FontSize',15);
% get(h_x);
% h_y=ylabel('$\dot{\psi}_1$','Interpreter','latex','FontSize',15);
% get(h_y);
axis([-2 2 -2 2]);
ROA_plot;

x1= linspace(-2,2,201);   % delta
x2= linspace(-2,2,201);   % omega

keep_data=zeros(numel(x1),numel(x2),3);               % 1-delta   2-omega 3-z
xs = apxGrid('expand',{x1',x2'});
[ymu ys2 fmu fs2] = gp(hyp2, @infGaussLik, meanfunc, covfunc, likfunc, x, y, xs);

mat_ymu=vec2mat(ymu,numel(x1))';
mat_ys2=vec2mat(sqrt(ys2),numel(x2))';

for i=1:numel(x1)
    
    for j=1:numel(x2)
        
        keep_data(i,j,1)=x1(i);                                    % delta
        keep_data(i,j,2)=x2(j);                                    % omega
        keep_data(i,j,3)=mat_ymu(i,j)+beta_sq*(mat_ys2(i,j))-Vmax;
    
    end
    
end

% To plot the predictive mean at the test points together with the 
% 95% confidence bounds and training data 

figure(2)

for i=1:numel(x1)
    
    for j=1:numel(x2)
        
        if (keep_data(i,j,3)<=0)&&(InROA(keep_data(i,j,1),keep_data(i,j,2))==0)
          
            plot(keep_data(i,j,1),keep_data(i,j,2),'y.');
            hold on
    
        end
        
    end
    
end

ROA_plot;
hold on
plot(sp(:,1), sp(:,2), 'g+', 'MarkerSize',5, 'LineWidth', 2); 
hold on
grid on
axis([-2 2 -2 2]);

% h_x=xlabel('$\psi_1$','Interpreter','latex','FontSize',18);
% get(h_x);
% h_y=ylabel('$\dot{\psi}_1$','Interpreter','latex','FontSize',18);
% get(h_y);

axis on;
box on;
