function ROA_plot


xCenter = 0;
yCenter = 0;
xRadius = sqrt(18.45/10);
yRadius = sqrt(18.45/12);

theta = 0 : 0.1 : 2*pi;

x = xRadius * cos(theta) + xCenter;
y = yRadius * sin(theta) + yCenter;

plot(x, y, 'r.', 'LineWidth', 2);

% fill(x,y,'r','edgecolor','none');
    
end
