% Interpolation method to look for Vmax

function [output, input sig] = Sampling(c_eq,x0)

tspan = linspace(0,100,201);

sig=0;                                                                        % 0-stable sampling point; 1-unstable sampling point
input=[];
output=[];

[t,x] = ode23(@swing, tspan, x0);

if(norm(x(end,:)-c_eq)<0.1)

    input=[x(1,1) x(1,2)];
    output = LPF(t(1:end),x(1:end,:));                             % the error for Lyapunov function
                                                                                 % feasible sampling sequence
else

    sig=1;                      % unstable sampling points

   % continue;                                                            % infeasible sampling sequence    

end
        
end